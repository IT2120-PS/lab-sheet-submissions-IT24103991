getwd()
setwd("C:/Users/IT24103991/Desktop/IT24103991")


#EXERCISE 01

#Q1
branch_data <- read.csv("Exercise.txt") #Stored in a dataset called branc_data

#Q2
# Branch: categorical
# Sales_X1: quantitative
# Advertising_X2: quantitative
# Years_X3: quantitative

#Q3
boxplot(branch_data$Sales_X1,Main="Box plot of sales ")

#Q4
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5

branch_data$Years_X3 <- as.numeric(as.character(branch_data$Years_X3))


Q1 <- quantile(branch_data$Years_X3, 0.25)
Q3 <- quantile(branch_data$Years_X3, 0.75)
IQR_value <- IQR(branch_data$Years_X3)

lower_bound <- Q1 - 1.5 * IQR_value
upper_bound <- Q3 + 1.5 * IQR_value

outliers <- branch_data$Years_X3[branch_data$Years_X3 < lower_bound | branch_data$Years_X3 > upper_bound]
outliers

